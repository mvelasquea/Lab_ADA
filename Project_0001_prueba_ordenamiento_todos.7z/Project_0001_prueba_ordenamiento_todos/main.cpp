/**************************************************
Professor: D.Sc. Manuel Eduardo Loaiza Fernandez
Course: Analisis y Diseno de Algoritmos
UNSA - 2024 - II
**************************************************/
// mergesort , bubble sort y quick sort , comparando con los de introsort y heapsort , 
// evaluando con datos dentrode un arreglo
#include <iostream>

#ifdef _WIN32
    #define CLEAR_COMMAND "cls"
#elif defined(__APPLE__) || defined(__MACH__) || defined(__linux__)
    #include <unistd.h>
    #include <termios.h>
    #define CLEAR_COMMAND "clear"
#endif

void cover_function()
{
	std::cout << "\x1B[H";          // Codigo para colocar el cursor en el canto superior izquierdo

    std::cout << "\x1B[1;36;44m";         // Mostrar el siguiente texto en modo de letra italico "[3;" y color azul "[ ;34m"	
	std::cout << "/***************************************************/" << std::endl; 
	std::cout << "\x1B[m";             // Resetear color a valor por defecto
	std::cout << "\x1B[31;1m Universidad Nacional de San Agustin \x1B[m" << std::endl; 
	std::cout << "\x1B[33;1m Escuela Profesional de Ingenieria de Sistemas \x1B[m" << std::endl; 
	std::cout << "\x1B[37;1m Curso de Analisis y Diseno de Algoritmos \x1B[m" << std::endl; 
	std::cout << "\x1B[38;5;46m Velasque Arcos Mikhail Gabino \x1B[m" << std::endl; 
	std::cout << "\x1B[3;38;5;160m Arequipa 2024 - Semestre II \x1B[m" << std::endl; 
	std::cout << "\x1B[5;36;44m";         // Mostrar el siguiente texto en modo de letra italico "[3;" y color azul "[ ;34m"	
	std::cout << "/***************************************************/" << std::endl;
	std::cout << "\x1B[m";             // Resetear color a valor por defecto 
	
	return;
}


// Implementacion de los algoritmos de orfdemnamiento  ( buble , quick y mergsort 

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <algorithm> // Para std::copy

// Declaraciones de funciones
void bubbleSort(int arr[], int n);
void merge(int arr[], int left, int mid, int right);
void mergeSort(int arr[], int left, int right);
int partition(int arr[], int low, int high);
void quickSort(int arr[], int low, int high);
void printArray(int arr[], int n); //funcion apra imprimir los datos

int main() {
	
    // Generar un array dinámico de números enteros
	
    int n = 10; //tamaño del array
    int* arr = new int[n];
    std::srand(std::time(0)); // Inicializacion para números aleatorios

    for (int i = 0; i < n; i++) {
        arr[i] = std::rand() % 100; // Números aleatorios entre 0 y 99
    }

    std::cout << "Array original: ";
    printArray(arr, n);

    // Algoritmo de ordenamiento  mediante bubble sort
    int* arrBubble = new int[n];
    std::copy(arr, arr + n, arrBubble);
    bubbleSort(arrBubble, n);
    std::cout << "Array ordenado con Bubble Sort: ";
    printArray(arrBubble, n);
    delete[] arrBubble;

    // Algoritmo de ordenamiento mediante Merge sort

    int* arrMerge = new int[n];
    std::copy(arr, arr + n, arrMerge);
    mergeSort(arrMerge, 0, n - 1);
    std::cout << "Array ordenado con Merge Sort: ";
    printArray(arrMerge, n);
    delete[] arrMerge;

    // Algoritmo de ordenamiento mediante quicksort

    int* arrQuick = new int[n];
    std::copy(arr, arr + n, arrQuick);
    quickSort(arrQuick, 0, n - 1);
    std::cout << "Array ordenado con Quick Sort: ";
    printArray(arrQuick, n);
    delete[] arrQuick;

    delete[] arr;
    return 0;
}

//Bubble Sort
void bubbleSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                std::swap(arr[j], arr[j + 1]);
            }
        }
    }
}

//Merge Sort
void merge(int arr[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;
    int* L = new int[n1];
    int* R = new int[n2];
    for (int i = 0; i < n1; i++)
        L[i] = arr[left + i];
    for (int j = 0; j < n2; j++)
        R[j] = arr[mid + 1 + j];
    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }

    delete[] L;
    delete[] R;
}

void mergeSort(int arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }
}

//Quick Sort
int partition(int arr[], int low, int high) {
    int pivot = arr[high];
    int i = (low - 1);
    for (int j = low; j < high; j++) {
        if (arr[j] < pivot) {
            i++;
            std::swap(arr[i], arr[j]);
        }
    }
    std::swap(arr[i + 1], arr[high]);
    return (i + 1);
}

void quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;
}







