/**************************************************
Professor: D.Sc. Manuel Eduardo Loaiza Fernandez
Course: Analisis y Diseno de Algoritmos
UNSA - 2024 - II
**************************************************/
// ANSI Codes
// https://gist.github.com/fnky/458719343aabd01cfb17a3a4f7296797

#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <limits>

#ifdef _WIN32
    #define CLEAR_COMMAND "cls"
#elif defined(__APPLE__) || defined(__MACH__) || defined(__linux__)
    #include <unistd.h>
    #include <termios.h>
    #define CLEAR_COMMAND "clear"
#endif

void cover_function()
{
    std::cout << "\x1B[H";          // Codigo para colocar el cursor en el canto superior izquierdo

    std::cout << "\x1B[1;36;44m";         // Mostrar el siguiente texto en modo de letra italico "[3;" y color azul "[ ;34m"	
    std::cout << "/***************************************************/" << std::endl; 
    std::cout << "\x1B[m";             // Resetear color a valor por defecto
    std::cout << "\x1B[31;1m Universidad Nacional de San Agustin \x1B[m" << std::endl; 
    std::cout << "\x1B[33;1m Escuela Profesional de Ingenieria de Sistemas \x1B[m" << std::endl; 
    std::cout << "\x1B[37;1m Curso de Analisis y Diseno de Algoritmos \x1B[m" << std::endl; 
    std::cout << "\x1B[38;5;46m Velasque Arcos Mikhail Gabino \x1B[m" << std::endl; 
    //----------------------------------
    std::cout << "\x1B[3;38;5;160m Actividad 2 Tomar medida de tiempo de Algoritmos de Ordenamiento" << std::endl; 
    std::cout << "\x1B[3;38;5;160m Implementacion del Heapsort" << std::endl; 
    //----------------------------------
    std::cout << "\x1B[3;38;5;160m Arequipa 2024 - Semestre II \x1B[m" << std::endl; 
    std::cout << "\x1B[5;36;44m";         // Mostrar el siguiente texto en modo de letra italico "[3;" y color azul "[ ;34m"	
    std::cout << "/***************************************************/" << std::endl;
    std::cout << "\x1B[m";             // Resetear color a valor por defecto     
    return;
}

using namespace std;

// Función para intercambiar dos elementos
void swap(int& a, int& b) {
    int temp = a;
    a = b;
    b = temp;
}

// Función para mantener la propiedad del heap, creando la estructura de un árbol
void heapify(vector<int>& arr, int n, int i) {
    int largest = i; // Inicializar el nodo más grande como raíz
    int left = 2 * i + 1; // Hijo izquierdo
    int right = 2 * i + 2; // Hijo derecho

    // Si el hijo izquierdo es mayor que la raíz
    if (left < n && arr[left] > arr[largest])
        largest = left;

    // Si el hijo derecho es mayor que el nodo más grande hasta ahora
    if (right < n && arr[right] > arr[largest])
        largest = right;

    // Si el nodo más grande no es la raíz
    if (largest != i) {
        swap(arr[i], arr[largest]); // Intercambiar

        // Recursivamente heapificar el subárbol afectado
        heapify(arr, n, largest);
    }
}

// Función principal para ordenar un arreglo usando Heapsort
void heapSort(vector<int>& arr) {
    int n = arr.size();

    // Construir el heap (reorganizar el arreglo)
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);

    // Extraer elementos uno por uno del heap
    for (int i = n - 1; i > 0; i--) {
        swap(arr[0], arr[i]); // Mover la raíz actual al final
        heapify(arr, i, 0); // Llamar a heapify en el heap reducido
    }
}

// Casos de ordenamiento 
//caso 1 Desordenado
void generarVectorDesordenado(vector<int>& arr, int n) {
    for (int i = 0; i < n; i++) {
        arr.push_back(rand() % 1000);
    }
}
//caso 2 mitad ordenado mitad Desordenado

void generarVectorMitadDesordenado(vector<int>& arr, int n) {
    for (int i = 0; i < n / 2; i++) {
        arr.push_back(rand() % 1000);
    }
    for (int i = n / 2; i < n; i++) {
        arr.push_back(i); // ya ordenado
    }
}
//caso 3 ordenado acendente

void generarVectorOrdenado(vector<int>& arr, int n) {
    for (int i = 0; i < n; i++) {
        arr.push_back(i);
    }
}
//caso 4 ordenado desendente

void generarVectorOrdenadoDescendente(vector<int>& arr, int n) {
    for (int i = n; i > 0; i--) {
        arr.push_back(i);
    }
}

// Función para medir el tiempo de ejecución
double medirTiempo(void (*func)(vector<int>&), vector<int>& arr) {
    auto start = chrono::high_resolution_clock::now();
    func(arr);
    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> duration = end - start;
    return duration.count();
}

// Función para mostrar el mejor y peor tiempo
void mostrarMejorPeorTiempo(double mejor, double peor) {
    cout << "Mejor tiempo de ejecucion: " << mejor << " segundos" << endl;
    cout << "Peor tiempo de ejecucion: " << peor << " segundos" << endl;
}

// Función principal
int main() {
    srand(static_cast<unsigned>(time(0))); // Inicializar la semilla para números aleatorios

    double mejorTiempo = std::numeric_limits<double>::max(); // Inicializar con el valor máximo posible
    double peorTiempo = std::numeric_limits<double>::min(); // Inicializar con el valor mínimo posible
    string mejorCaso, peorCaso;

    for (int n = 100; n <= 10000; n += 100) {
        vector<int> arr;

        // Caso 1: Vector desordenado
        generarVectorDesordenado(arr, n);
        double tiempoDesordenado = medirTiempo(heapSort, arr);
        cout << "Tamaño : " << n << ", Desordenado: " << tiempoDesordenado << " segundos" << endl;
        if (tiempoDesordenado < mejorTiempo) {
            mejorTiempo = tiempoDesordenado;
            mejorCaso = "Desordenado";
        }
        if (tiempoDesordenado > peorTiempo) {
            peorTiempo = tiempoDesordenado;
            peorCaso = "Desordenado";
        }

        // Caso 2: Vector mitad desordenado y mitad ordenado
        generarVectorMitadDesordenado(arr, n);
        double tiempoMitadDesordenado = medirTiempo(heapSort, arr);
        cout << "Tamaño: " << n << ", Mitad desordenado: " << tiempoMitadDesordenado << " segundos" << endl;
        if (tiempoMitadDesordenado < mejorTiempo) {
            mejorTiempo = tiempoMitadDesordenado;
            mejorCaso = "Mitad desordenado";
        }
        if (tiempoMitadDesordenado > peorTiempo) {
            peorTiempo = tiempoMitadDesordenado;
            peorCaso = "Mitad desordenado";
        }

        // Caso 3: Vector ordenado de menor a mayor
        generarVectorOrdenado(arr, n);
        double tiempoOrdenado = medirTiempo(heapSort, arr);
        cout << "Tamaño: " << n << ", Ordenado: " << tiempoOrdenado << " segundos" << endl;
        if (tiempoOrdenado < mejorTiempo) {
            mejorTiempo = tiempoOrdenado;
            mejorCaso = "Ordenado";
        }
        if (tiempoOrdenado > peorTiempo) {
            peorTiempo = tiempoOrdenado;
            peorCaso = "Ordenado";
        }

        // Caso 4: Vector ordenado de mayor a menor
        generarVectorOrdenadoDescendente(arr, n);
        double tiempoOrdenadoDescendente = medirTiempo(heapSort, arr);
        cout << "Tamaño: " << n << ", Ordenado descendente: " << tiempoOrdenadoDescendente << " segundos" << endl;
        if (tiempoOrdenadoDescendente < mejorTiempo) {
            mejorTiempo = tiempoOrdenadoDescendente;
            mejorCaso = "Ordenado descendente";
        }
        if (tiempoOrdenadoDescendente > peorTiempo) {
            peorTiempo = tiempoOrdenadoDescendente;
            peorCaso = "Ordenado descendente";
        }
    }

    cout << "Mejor caso: " << mejorCaso << endl;
    cout << "Peor caso: " << peorCaso << endl;

    mostrarMejorPeorTiempo(mejorTiempo, peorTiempo);

    return 0;
}