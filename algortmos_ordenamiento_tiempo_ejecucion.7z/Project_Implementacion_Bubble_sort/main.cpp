/**************************************************
Professor: D.Sc. Manuel Eduardo Loaiza Fernandez
Course: Analisis y Diseno de Algoritmos 
UNSA - 2024 - II
**************************************************/
// ANSI Codes
// https://gist.github.com/fnky/458719343aabd01cfb17a3a4f7296797

#include <iostream>

#ifdef _WIN32
    #define CLEAR_COMMAND "cls"
#elif defined(__APPLE__) || defined(__MACH__) || defined(__linux__)
    #include <unistd.h>
    #include <termios.h>
    #define CLEAR_COMMAND "clear"
#endif

void cover_function()
{
    std::cout << "\x1B[H";          // Codigo para colocar el cursor en el canto superior izquierdo

    std::cout << "\x1B[1;36;44m";         // Mostrar el siguiente texto en modo de letra italico "[3;" y color azul "[ ;34m"	
    std::cout << "/***************************************************/" << std::endl; 
    std::cout << "\x1B[m";             // Resetear color a valor por defecto
    std::cout << "\x1B[31;1m Universidad Nacional de San Agustin \x1B[m" << std::endl; 
    std::cout << "\x1B[33;1m Escuela Profesional de Ingenieria de Sistemas \x1B[m" << std::endl; 
    std::cout << "\x1B[37;1m Curso de Analisis y Diseno de Algoritmos \x1B[m" << std::endl; 
    std::cout << "\x1B[38;5;46m Velasque Arcos Mikhail Gabino \x1B[m" << std::endl; 
    //----------------------------------
    std::cout << "\x1B[3;38;5;160m Actividad 2 Tomar medida de tiempo de Algoritmos de Ordenamiento" << std::endl; 
    std::cout << "\x1B[3;38;5;160m Implementacion del Bubble_sort" << std::endl; 
    //----------------------------------
    std::cout << "\x1B[3;38;5;160m Arequipa 2024 - Semestre II \x1B[m" << std::endl; 
    std::cout << "\x1B[5;36;44m";         // Mostrar el siguiente texto en modo de letra italico "[3;" y color azul "[ ;34m"	
    std::cout << "/***************************************************/" << std::endl;
    std::cout << "\x1B[m";             // Resetear color a valor por defecto     
    return;
}

#include <vector>
#include <cstdlib>
#include <ctime>
#include <chrono>

using namespace std; // namespace o sea nombre del sitio de trabajo 

// Función para intercambiar dos elementos 
void swap(int& a, int& b) {
    int temp = a; // Variable temporal para el intercambio los valores
    a = b;
    b = temp;
}

// Función para ordenar con el algoritmo de Bubble_sort 
void bubbleSort(vector<int>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
            }
        }
    }
}

// Primer caso , vector desordenado
void generarVectorDesordenado(vector<int>& arr, int n) {
    for (int i = 0; i < n; i++) {
        arr.push_back(rand() % 1000);
    }
}

// Segundo caso , vector desordenado mitad desordenado y mitad ordenado
void generarVectorMitadDesordenado(vector<int>& arr, int n) {
    for (int i = 0; i < n / 2; i++) {
        arr.push_back(rand() % 1000);
    }
    for (int i = n / 2; i < n; i++) {
        arr.push_back(i); // ya ordenado
    }
}

// Tercer caso ,vector ordenado de menor a mayor
void generarVectorOrdenado(vector<int>& arr, int n) {
    for (int i = 0; i < n; i++) {
        arr.push_back(i);
    }
}

// cuarto caso vector ordenado de mayor a menor
void generarVectorOrdenadoDescendente(vector<int >& arr, int n) {
    for (int i = n; i > 0; i--) {
        arr.push_back(i);
    }
}

// Función para tomar el tiempo de ejecución de el algoritmo en cada uno de los casos
double medirTiempo(void (*func)(vector<int>&), vector<int>& arr) {//funcion que recibe el vector  , dependiendo el caso obviamente
    auto start = chrono::high_resolution_clock::now();
    func(arr);
    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> duration = end - start;
    return duration.count();
}

// Función para mostrar el mejor y peor tiempo en cada uno de los casos
void mostrarMejorPeorTiempo(double mejor, double peor) {
    cout << "Mejor tiempo de ejecucion: " << mejor << " segundos" << endl;
    cout << "Peor tiempo de ejecucion: " << peor << " segundos" << endl;
}

// Función principal , ejecutando los casos con sus respectivos datos de 1 al 1000   , con amplitud de 100 a 100
int main() {
    srand(static_cast<unsigned>(time(0))); // Inicializar la semilla para números aleatorios

    double mejorTiempo = std::numeric_limits<double>::max(); // Inicializar con el valor máximo posible
    double peorTiempo = std::numeric_limits<double>::min(); // Inicializar con el valor mínimo posible

    for (int n = 100; n <= 10000; n += 100) {
        vector<int> arr;

        // Caso 1: Vector desordenado
        generarVectorDesordenado(arr, n);
        double tiempoDesordenado = medirTiempo(bubbleSort, arr);
        cout << "Tamaño: " << n << ", Desordenado: " << tiempoDesordenado << " segundos" << endl;
        mejorTiempo = min(mejorTiempo, tiempoDesordenado);
        peorTiempo = max(peorTiempo, tiempoDesordenado);

        // Caso 2: Vector mitad desordenado y mitad ordenado
        arr.clear();
        generarVectorMitadDesordenado(arr, n);
        double tiempoMitadDesordenado = medirTiempo(bubbleSort, arr);
        cout << "Tamaño: " << n << ", Mitad Desordenado: " << tiempoMitadDesordenado << " segundos" << endl;
        mejorTiempo = min(mejorTiempo, tiempoMitadDesordenado);
        peorTiempo = max(peorTiempo, tiempoMitadDesordenado);

        // Caso 3: Vector ordenado de menor a mayor
        arr.clear();
        generarVectorOrdenado(arr, n);
        double tiempoOrdenado = medirTiempo(bubbleSort, arr);
        cout << "Tamaño: " << n << ", Ordenado: " << tiempoOrdenado << " segundos" << endl;
        mejorTiempo = min(mejorTiempo, tiempoOrdenado );
        peorTiempo = max(peorTiempo, tiempoOrdenado);

        // Caso 4: Vector ordenado de mayor a menor
        arr.clear();
        generarVectorOrdenadoDescendente(arr, n);
        double tiempoOrdenadoDescendente = medirTiempo(bubbleSort, arr);
        cout << "Tamaño: " << n << ", Ordenado Descendente: " << tiempoOrdenadoDescendente << " segundos" << endl;
        mejorTiempo = min(mejorTiempo, tiempoOrdenadoDescendente);
        peorTiempo = max(peorTiempo, tiempoOrdenadoDescendente);
    }

    mostrarMejorPeorTiempo(mejorTiempo, peorTiempo);

    return 0;
}