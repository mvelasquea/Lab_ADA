/**************************************************
Professor: D.Sc. Manuel Eduardo Loaiza Fernandez
Course: Analisis y Diseno de Algoritmos
Example: Heapsort  
UNSA - 2024 - II
**************************************************/
// Heapsort program 
// ANSI Codes
// https://gist.github.com/fnky/458719343aabd01cfb17a3a4f7296797

#include <iostream>

#ifdef _WIN32
    #define CLEAR_COMMAND "cls"
#elif defined(__APPLE__) || defined(__MACH__) || defined(__linux__)
    #include <unistd.h>
    #include <termios.h>
    #define CLEAR_COMMAND "clear"
#endif

void cover_function()
{
	std::cout << "\x1B[H";          // Codigo para colocar el cursor en el canto superior izquierdo

    std::cout << "\x1B[1;36;44m";         // Mostrar el siguiente texto en modo de letra italico "[3;" y color azul "[ ;34m"	
	std::cout << "/***************************************************/" << std::endl; 
	std::cout << "\x1B[m";             // Resetear color a valor por defecto
	std::cout << "\x1B[31;1m Universidad Nacional de San Agustin \x1B[m" << std::endl; 
	std::cout << "\x1B[33;1m Escuela Profesional de Ingenieria de Sistemas \x1B[m" << std::endl; 
	std::cout << "\x1B[37;1m Curso de Analisis y Diseno de Algoritmos \x1B[m" << std::endl; 
	std::cout << "\x1B[38;5;46m Miku Miku \x1B[m" << std::endl; 
	std::cout << "\x1B[3;38;5;160m Arequipa 2024 - Semestre II \x1B[m" << std::endl; 
	std::cout << "\x1B[5;36;44m";         // Mostrar el siguiente texto en modo de letra italico "[3;" y color azul "[ ;34m"	
	std::cout << "/***************************************************/" << std::endl;
	std::cout << "\x1B[m";             // Resetear color a valor por defecto 
	std::cout << "\n !! Welcome to 2024 - II semester !! \n\n";
	
	return;
}


// C++ program for implementation of Heap Sort

// To heapify a subtree rooted with node i which is
// an index in arr[]. n is size of heap
void heapify(int arr[], int n, int i)
{
	int largest = i; // Initialize largest as root Since we are using 0 based indexing
	int l = 2 * i + 1; // left = 2*i + 1
	int r = 2 * i + 2; // right = 2*i + 2

	// If left child is larger than root
	if (l < n && arr[l] > arr[largest])
	{
		largest = l;
	}

	// If right child is larger than largest so far
	if (r < n && arr[r] > arr[largest])
	{
		largest = r;
	}

	// If largest is not root
	if (largest != i) 
	{
		std::swap(arr[i], arr[largest]);

		// Recursively heapify the affected sub-tree
		heapify(arr, n, largest);
	}
}

// main function to do heap sort
void heapSort(int arr[], int n)
{
	// Build heap (rearrange array)
	for (int i = n / 2 - 1; i >= 0; i--)
	{
		heapify(arr, n, i);
	}

	// One by one extract an element from heap
	for (int i = n - 1; i >= 0; i--) 
	{
		// Move current root to end
		std::swap(arr[0], arr[i]);

		// call max heapify on the reduced heap
		heapify(arr, i, 0);
	}
}

/* A utility function to print array of size n */
void printArray(int arr[], int n)
{
	for (int i = 0; i < n; ++i)
	{
		std::cout << arr[i] << " ";
	}
	std::cout << "\n";
	return;
}

// Driver program
int main()
{
	std::system(CLEAR_COMMAND);            // Comando para borrar todo el contenido de la pantalla
	cover_function();

	int arr[] = { 60 ,20 ,40 ,70, 30, 10 , 50, 30, 90, 80};
	int n = sizeof(arr) / sizeof(arr[0]);
	
	//heapify algorithm
	// the loop must go reverse you will get after analyzing manually 
	// (i=n/2 -1) because other nodes/ ele's are leaf nodes 
	// (i=n/2 -1) for 0 based indexing
	// (i=n/2) for 1 based indexing
	for(int i=n/2 -1;i>=0;i--)
	{
		heapify(arr,n,i);
	}

	std::cout << "After heapifying array is \n";
	printArray(arr, n);

	heapSort(arr, n);

	std::cout << "Sorted array is \n";
	printArray(arr, n);
	
	return 0;
}
   


























