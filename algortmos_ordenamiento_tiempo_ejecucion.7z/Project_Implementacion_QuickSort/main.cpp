/**************************************************
Professor: D.Sc. Manuel Eduardo Loaiza Fernandez
Course: Analisis y Diseno de Algoritmos
UNSA - 2024 - II
**************************************************/
// ANSI Codes
// https://gist.github.com/fnky/458719343aabd01cfb17a3a4f7296797

#include <iostream>

#ifdef _WIN32
    #define CLEAR_COMMAND "cls"
#elif defined(__APPLE__) || defined(__MACH__) || defined(__linux__)
    #include <unistd.h>
    #include <termios.h>
    #define CLEAR_COMMAND "clear"
#endif

void cover_function()
{
    std::cout << "\x1B[H";          // Codigo para colocar el cursor en el canto superior izquierdo

    std::cout << "\x1B[1;36;44m";         // Mostrar el siguiente texto en modo de letra italico "[3;" y color azul "[ ;34m"	
    std::cout << "/***************************************************/" << std::endl; 
    std::cout << "\x1B[m";             // Resetear color a valor por defecto
    std::cout << "\x1B[31;1m Universidad Nacional de San Agustin \x1B[m" << std::endl; 
    std::cout << "\x1B[33;1m Escuela Profesional de Ingenieria de Sistemas \x1B[m" << std::endl; 
    std::cout << "\x1B[37;1m Curso de Analisis y Diseno de Algoritmos \x1B[m" << std::endl; 
    std::cout << "\x1B[38;5;46m Velasque Arcos Mikhail Gabino \x1B[m" << std::endl; 
    //----------------------------------
    std::cout << "\x1B[3;38;5;160m Actividad 2 Tomar medida de tiempo de Algoritmos de Ordenamiento" << std::endl; 
    std::cout << "\x1B[3;38;5;160m Implementacion del Quick_sort" << std::endl; 
    //----------------------------------
    std::cout << "\x1B[3;38;5;160m Arequipa 2024 - Semestre II \x1B[m" << std::endl; 
    std::cout << "\x1B[5;36;44m";         // Mostrar el siguiente texto en modo de letra italico "[3;" y color azul "[ ;34m"	
    std::cout << "/***************************************************/" << std::endl;
    std::cout << "\x1B[m";             // Resetear color a valor por defecto     
    return;
}

#include <vector>
#include <cstdlib>
#include <ctime>
#include <chrono>

using namespace std; // namespace o sea nombre del sitio de trabajo 

// Función para intercambiar dos elementos 
void swap(int& a, int& b) {
    int temp = a; // Variable temporal para el intercambio los valores
    a = b;
    b = temp;
}

// Función para particionar el arreglo , se usara dentro de la funcion de quicksort , 
int partition(vector<int>& arr, int low, int high) {
    int pivot = arr[high]; // Elegir el último elemento como pivote
    int i = low - 1; // Índice del elemento más pequeño

    for (int j = low; j < high; j++) {
        if (arr[j] < pivot) {
            i++; // Incrementar el índice del elemento más pequeño
            swap(arr[i], arr[j]); // Intercambiar
        }
    }
    swap(arr[i + 1], arr[high]); // Colocar el pivote en su posición correcta
    return i + 1; // Retornar la posición del pivote
}

// Función para ordenar con el algoritmo de Quicksort
void quickSort(vector<int>& arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high); // Particionar el arreglo

        // Recursivamente ordenar los elementos antes y después de la partición
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

// Funciones para generar diferentes tipos de arreglos
void generarVectorDesordenado(vector<int>& arr, int n) {
    for (int i = 0; i < n; i++) {
        arr.push_back(rand() % 1000);
    }
}

void generarVectorMitadDesordenado(vector<int>& arr, int n) {
    for (int i = 0; i < n / 2; i++) {
        arr.push_back(rand() % 1000);
    }
    for (int i = n / 2; i < n; i++) {
        arr.push_back(i); // ya ordenado
    }
}

void generarVectorOrdenado(vector<int>& arr, int n) {
    for (int i = 0; i < n; i++) {
        arr.push_back(i);
    }
}

void generarVectorOrdenadoDescendente(vector<int>& arr, int n) {
    for (int i = n; i > 0; i--) {
        arr.push_back(i);
    }
}

// Función para medir el tiempo de ejecución
double medirTiempo(void (*func)(vector<int>&, int, int), vector<int>& arr, int left, int right) {
    auto start = chrono::high_resolution_clock::now();
    func(arr, left, right);
    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> duration = end - start;
    return duration.count();
}

// Función para mostrar el mejor y peor tiempo
void mostrarMejorPeorTiempo(double mejor, double peor) {
    cout << "Mejor tiempo de ejecucion: " << mejor << " segundos" << endl;
    cout << "Peor tiempo de ejecucion: " << peor << " segundos" << endl;
}

// Función principal
int main() {
    srand(static_cast<unsigned>(time(0))); // Inicializar la semilla para números aleatorios

    double mejorTiempo = std::numeric_limits<double>::max(); // Inicializar con el valor máximo posible
    double peorTiempo = std::numeric_limits<double>::min(); // Inicializar con el valor mínimo posible

    for (int n = 100; n <= 10000; n += 100) {
        vector<int> arr;

        // Caso 1: Vector desordenado
        generarVectorDesordenado(arr, n);
        double tiempoDesordenado = medirTiempo(quickSort, arr, 0, arr.size() - 1);
        cout << "Tamaño: " << n << ", Desordenado: " << tiempoDesordenado << " segundos" << endl;
        mejorTiempo = min(mejorTiempo, tiempoDesordenado);
        peorTiempo = max(peorTiempo, tiempoDesordenado);

        // Caso 2: Vector mitad desordenado y mitad ordenado
        generarVectorMitadDesordenado(arr, n);
        double tiempoMitadDesordenado = medirTiempo(quickSort, arr, 0, arr.size() - 1);
        cout << "Tamaño: " << n << ", Mitad desordenado: " << tiempoMitadDesordenado << " segundos" << endl;
        mejorTiempo = min(mejorTiempo, tiempoMitadDesordenado);
        peorTiempo = max(peorTiempo, tiempoMitadDesordenado);

        // Caso 3: Vector ordenado de menor a mayor
        generarVectorOrdenado(arr, n);
        double tiempoOrdenado = medirTiempo(quickSort, arr, 0, arr.size() - 1);
        cout << "Tamaño: " << n << ", Ordenado: " << tiempoOrdenado << " segundos" << endl;
        mejorTiempo = min(mejorTiempo, tiempoOrdenado);
        peorTiempo = max(peorTiempo, tiempoOrdenado);

        // Caso 4: Vector ordenado de mayor a menor
        generarVectorOrdenadoDescendente(arr, n);
        double tiempoOrdenadoDescendente = medirTiempo(quickSort, arr, 0, arr.size() - 1);
        cout << "Tamaño: " << n << ", Ordenado descendente: " << tiempoOrdenadoDescendente << " segundos" << endl;
        mejorTiempo = min(mejorTiempo, tiempoOrdenadoDescendente);
        peorTiempo = max(peorTiempo, tiempoOrdenadoDescendente);
    }

    mostrarMejorPeorTiempo(mejorTiempo, peorTiempo);

    return 0;
}